import SwiftUI

struct ElementDetailView: View{
    var element:Atom
    var body: some View{
        AtomView(selectedAtom: element)
        NavigationStack{
            Form{
                switch element.isIon(){
                    
                case 1:
                    Text("Symbol: \(element.symbol)⁻")
                case 2:
                    Text("Symbol: \(element.symbol)⁺")
                default:
                    Text("Symbol: \(element.symbol)")    
                }
                Text("Total Electrons: \(element.electrons)")
                Text("Total Neutrons: \(element.neutrons)")
                Text("Atomic Number: \(element.protons)")
                Text("Atomic Mass: \(element.mass)")
                Text("Category: \(element.category.rawValue)")
            }
            .navigationTitle(element.name)
        }
        
    }
}
