import SwiftUI
//⁺⁻
struct AtomView: View, Identifiable{
    var selectedAtom:Atom
    var id=UUID()
    var bounds:CGFloat = 200
    var body: some View{
        Group{
            if selectedAtom.symbol == "Q"{
                EmptyView()
                
            }else{
                ZStack{
                    ForEach(selectedAtom.electronShells.indices.reversed(),id:\.self){shell in
                        ShellView(n: shell+1, elects: selectedAtom.electronShells[shell], color: selectedAtom.category.color(), bound: bounds)
                        
                    }
                    ZStack{
                        NavigationLink{
                            ElementDetailView(element: selectedAtom)
                        }label:{
                            Circle()
                                .frame(width: bounds/5)
                                .foregroundColor(selectedAtom.category.color())
                        }
                        VStack{
                            switch selectedAtom.isIon(){
                                
                            case 1:
                                Text("\(selectedAtom.symbol)⁻")
                            case 2:
                                Text("\(selectedAtom.symbol)⁺")
                            default:
                                Text(selectedAtom.symbol)    
                            }
                            
                            
                            Text("\(selectedAtom.protons) P (+)")
                            Text("\(selectedAtom.neutrons) N")
                        }
                        .foregroundColor(.white)
                        .offset(y:bounds / -200)
                        .font(.system(size: bounds/20))
                    }
                    .onAppear(){
                        //print(selectedAtom.electronShells)
                        //print(bounds)
                    }
                    
                }
            }
        }
        .frame(height: bounds)
    }
}

struct AtomView_Previews:PreviewProvider{
    static var previews: some View{
        AtomView(selectedAtom: Oganesson)
            .preferredColorScheme(.light)
    }
}
struct ShellView:View{
    var n:Int
    var elects:Int
    var color: Color
    var bound: CGFloat
    var body: some View{
        
        if elects > 0{
            
            
            ZStack{
                Circle()
                    .foregroundColor(.black)
                    .frame(width: CGFloat((n+2))*bound/10)
                Circle()
                    .foregroundColor(.white)
                    .frame(width: CGFloat((n+2))*bound/10-10)
                ForEach(0...elects,id:\.self){elect in
                    ZStack{
                        Circle()
                            .foregroundStyle(color)
                        Text("-")
                            .foregroundStyle(Color.white)
                    }
                        .frame(width: bound/25)
                        .offset(x:elecPosition(elecNum: elect, shellNum: n, boun: Int(bound))[0],y:elecPosition(elecNum: elect, shellNum: n,boun: Int(bound))[1])
                        
                }
            }
            
            
        }
    }
}

func elecPosition(elecNum:Int,shellNum:Int, boun:Int)->[CGFloat]{
    let radius:CGFloat = CGFloat(((shellNum+2)*boun/10-4)/2)
    switch elecNum{
    case 0:
        return [0,0]
    case 1:
        return [0,-radius]
    case 2:
        return [0,radius]
    case 3:
        return [-radius,0]
    case 4:
        return [radius,0]
    case 5:
        return [-radius*0.7,-radius*0.7]
    case 6:
        return [-radius*0.7,radius*0.7]
    case 7:
        return [radius*0.7,-radius*0.7]
    case 8:
        return [radius*0.7,radius*0.7]
    case 9:
        return [-radius*0.92,-radius*0.4]
    case 10:
        return [-radius*0.4,-radius*0.92]
    case 11:
        return [radius*0.4,-radius*0.92]
    case 12:
        return [radius*0.92,-radius*0.4]
    case 13:
        return [radius*0.92,radius*0.4]
    case 14:
        return [radius*0.4,radius*0.92]
    case 15:
        return [-radius*0.4,radius*0.92]
    case 16:
        return [-radius*0.92,radius*0.4]
    case 17:
        return [-radius*0.96,-radius*0.24]
    case 18:
        return [-radius*0.8,-radius*0.6]
    case 19:
        return [-radius*0.6,-radius*0.8]
    case 20:
        return [-radius*0.24,-radius*0.96]
    case 21:
        return [radius*0.24,-radius*0.96]
    case 22:
        return [radius*0.6,-radius*0.8]
    case 23:
        return [radius*0.8,-radius*0.6]
    case 24:
        return [radius*0.96,-radius*0.24]
    case 25:
        return [radius*0.96,radius*0.24]
    case 26:
        return [radius*0.8,radius*0.6]
    case 27:
        return [radius*0.6,radius*0.8]
    case 28:
        return [radius*0.24,radius*0.96]
    case 29:
        return [-radius*0.24,radius*0.96]
    case 30:
        return [-radius*0.6,radius*0.8]
    case 31:
        return [-radius*0.8,radius*0.6]
    case 32:
        return [-radius*0.96,radius*0.24]
    default:
        return [0,0]
        
        
    }
}
