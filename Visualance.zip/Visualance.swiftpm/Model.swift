import SwiftUI

struct Atom:Identifiable, Equatable, Hashable{
    var symbol:String
    var name:String
    var id=UUID()
    var electrons:Int//negative charge, ion
    var neutrons:Int//isotopes
    var protons:Int//positive charge, always same
    var category:ElementCategory{
        switch groupNumber{
        case 1:
            if periodNumber == 1{
                return .reactiveNonMetal
            }else{
                return .alkaliMetal
            }
        case 2:
            return .alkalineEarthMetal
        case 3:
            if periodNumber == 6{
                return .lanthanide
            }else if periodNumber == 7{
                return .actinide
            }else{
                return .transitionMetal
            }
        case 4:
            fallthrough
        case 5:
            fallthrough
        case 6:
            fallthrough
        case 7:
            fallthrough
        case 8:
            fallthrough
        case 9:
            fallthrough
        case 10:
            fallthrough
        case 11:
            fallthrough
        case 12:
            return .transitionMetal
        case 13:
            if periodNumber == 2{
                return .metalloid
            }else{
                return .postTransitionMetal
            }
        case 14:
            if periodNumber == 2{
                return .reactiveNonMetal
            }else if periodNumber <= 4{
                return .metalloid
            }else{
                return .postTransitionMetal
            }
        case 15:
            if periodNumber<=3{
                return .reactiveNonMetal
            }else if periodNumber <= 5{
                return .metalloid
            }else{
                return .postTransitionMetal
            }
        case 16:
            if periodNumber<=4{
                return .reactiveNonMetal
            }else if periodNumber==5{
                return .metalloid
            }else{
                return .postTransitionMetal
            }
        case 17:
            if periodNumber <= 5{
                return .reactiveNonMetal
            }else{
                return .postTransitionMetal
            }
        case 18:
            return .nobleGas
        default:
            return .unknown
        }
    }//type based on place in periodic table
    var mass:Int{ return protons+neutrons }//atomic mass
    func isIon()->Int{
        if electrons>protons{
            return 1 //negative
        }else if electrons<protons{
            return 2 //positive
        }else{
            return 0 //not ion
        }
        
    }
    var electronShells:[Int]{
        var tempElectron:Int=electrons
        var shellArray:[Int]=[0,0,0,0,0,0,0]
        for i in OgElectronConfig.indices{
            let j = OgElectronConfig[i]
            if tempElectron>=j{
                tempElectron-=j
                shellArray[OgElectronShell[i]-1]+=j
                //print(shellArray[OgElectronShell[i]-1],j)
            }else if tempElectron==0{
                break
            }else{
                shellArray[OgElectronShell[i]-1]+=tempElectron
                //print(shellArray[OgElectronShell[i]-1],j)
                break
            }
        }
        //print(shellArray)
        return shellArray
    }
    var groupNumber:Int
    var periodNumber:Int
    var description=""
    var valence: Int {
        var indi = 0
        var valen = 0
        while indi < 7 && valen == 0 {
            valen = electronShells.reversed()[indi]
            if valen == 0 {
                indi += 1
            }
        }
        //        print(valen)
        return valen
    }
    var isMetallic:Int{
        switch category{
        case .reactiveNonMetal:
            return 0 //not metallic
        case .metalloid:
            return 2 //metalloid
        default:
            return 1 //metallic
        }
    }
    var toStable:Int{
        if symbol=="H"{
            return 1
        }
        if category == .nobleGas{
            return 0
        }
        return 8-valence
    }
}

enum ElementCategory: String {
    case alkaliMetal = "Alkali Metal"
    case alkalineEarthMetal = "Alkali Earth Metal"
    case transitionMetal = "Transition Metal"
    case postTransitionMetal = "Post-Transition Metal"
    case metalloid = "Metalloid"
    case reactiveNonMetal = "Reactive Non-Metal"
    case nobleGas = "Noble Gas"
    case lanthanide = "Lanthanide"
    case actinide = "Actinide"
    case unknown = "Unknown"
    
    func color() -> Color {
        switch self {
        case .alkaliMetal:
            return .blue
        case .alkalineEarthMetal:
            return .green
        case .transitionMetal:
            return .orange
        case .postTransitionMetal:
            return .purple
        case .metalloid:
            return .red
        case .reactiveNonMetal:
            return .yellow
        case .nobleGas:
            return .pink
        case .lanthanide:
            return .cyan
        case .actinide:
            return .brown
        case .unknown:
            return .gray
        }
    }
}
extension String {
    var isNumber: Bool {
        let digitsCharacters = CharacterSet(charactersIn: "0123456789")
        return CharacterSet(charactersIn: self).isSubset(of: digitsCharacters)
    }
}

let OgElectronConfig=[2,2,6,2,6,10,2,6,10,2,6,14,10,2,6,14,10,2,6]
let OgElectronShell=[1,2,2,3,3,3,4,4,4,5,5,4,5,6,6,5,6,7,7]
var testAtom=Atom(symbol: "He", name: "Helium", electrons: 2, neutrons: 2, protons: 2,groupNumber: 18,periodNumber: 1)
var Oganesson=Atom(symbol: "Og", name: "Oganesson", electrons: 118, neutrons: 176, protons: 118,groupNumber: 18,periodNumber: 7)

var symbolString = "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og"
var nameString = "Hydrogen Helium Lithium Beryllium Boron Carbon Nitrogen Oxygen Fluorine Neon Sodium Magnesium Aluminium Silicon Phosphorus Sulfur Chlorine Argon Potassium Calcium Scandium Titanium Vanadium Chromium Manganese Iron Cobalt Nickel Copper Zinc Gallium Germanium Arsenic Selenium Bromine Krypton Rubidium Strontium Yttrium Zirconium Niobium Molybdenum Technetium Ruthenium Rhodium Palladium Silver Cadmium Indium Tin Antimony Tellurium Iodine Xenon Caesium Barium Lanthanum Cerium Praseodymium Neodymium Promethium Samarium Europium Gadolinium Terbium Dysprosium Holmium Erbium Thulium Ytterbium Lutetium Hafnium Tantalum Tungsten Rhenium Osmium Iridium Platinum Gold Mercury Thallium Lead Bismuth Polonium Astatine Radon Francium Radium Actinium Thorium Protactinium Uranium Neptunium Plutonium Americium Curium Berkelium Californium Einsteinium Fermium Mendelevium Nobelium Lawrencium Rutherfordium Dubnium Seaborgium Bohrium Hassium Meitnerium Darmstadtium Roentgenium Copernicium Nihonium Flerovium Moscovium Livermorium Tennessine Oganesson"
var protonArray = Array(1...118)
var weightString = "1.008 4.0026 6.94 9.0122 10.81 12.011 14.007 15.999 18.998 20.18 22.99 24.305 26.982 28.085 30.974 32.06 35.45 39.95 39.098 40.078 44.956 47.867 50.942 51.996 54.938 55.845 58.933 58.693 63.546 65.38 69.723 72.63 74.922 78.971 79.904 83.798 85.468 87.62 88.906 91.224 92.906 95.95 97 101.07 102.91 106.42 107.87 112.41 114.82 118.71 121.76 127.6 126.9 131.29 132.91 137.33 138.91 140.12 140.91 144.24 145 150.36 151.96 157.25 158.93 162.5 164.93 167.26 168.93 173.05 174.97 178.49 180.95 183.84 186.21 190.23 192.22 195.08 196.97 200.59 204.38 207.2 208.98 209 210 222 223 226 227 232.04 231.04 238.03 237 244 243 247 247 251 252 257 258 259 266 267 268 269 270 269 278 281 282 285 286 289 290 293 294 294"
var groupString = "1 18 1 2 13 14 15 16 17 18 1 2 13 14 15 16 17 18 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 1 2 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 1 2 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18"
var periodString = "1 1 2 2 2 2 2 2 2 2 3 3 3 3 3 3 3 3 4 4 4 4 4 4 4 4 4 4 4 4 4 4 4 4 4 4 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7 7"

var symbolArray = symbolString.components(separatedBy: " ")
var nameArray = nameString.components(separatedBy: " ")
var weightArray:[Int]{
    var returnArray:[Int]=[]
    let tempArray = weightString.components(separatedBy: " ")
    for i in tempArray.indices{
        returnArray.append(Int(Double(tempArray[i])!+0.5))
    }
    return returnArray
}
var groupArray:[Int]{
    var returnArray:[Int]=[]
    let tempArray = groupString.components(separatedBy: " ")
    for i in tempArray{
        returnArray.append(Int(i)!)
    }
    return returnArray
}
var periodArray:[Int]{
    var returnArray:[Int]=[]
    let tempArray = periodString.components(separatedBy: " ")
    for i in tempArray{
        returnArray.append(Int(i)!)
    }
    return returnArray
}
var periodicTable:[Atom]{
    var tempArray:[Atom]=[]
    for i in protonArray{
        let ind=i-1
        tempArray.append(Atom(symbol: symbolArray[ind], name: nameArray[ind], electrons: i, neutrons: weightArray[ind]-i, protons: i, groupNumber: groupArray[ind], periodNumber: periodArray[ind]))
    }
    return tempArray
}
let superscriptNums = ["⁰","¹","²","³","⁴","⁵","⁶","⁷","⁸","⁹"]
let subscriptNums = ["₀","₁","₂","₃","₄","₅","₆","₇","₈","₉"]
let ionSigns = ["⁺","⁻"]
extension String {
    var moleculeCalculated: [Molecule] {
        if !(self==""){
            var mole = [Molecule(atoms: [])]
            //            var numIndice = -1
            var ato=errorAtom
            var atoms:[Atom] = []
            var sym = ""
            var supScr = ""
            var subScr = "0"
//            var ion = 0
            //                  var letterElement = false
            let arrayed = self.unicodeScalars
            var tempSym = ""
            for i in arrayed{
                //                numIndice+=1
                if CharacterSet.uppercaseLetters.contains(i) {
                    sym+=String(i)
                    for j in periodicTable{
                        if j.symbol==String(i){
                            ato=j
                            print(ato.symbol)
                            print(j.symbol)
                            if !(supScr==""){
                            //    if ion==0{
                                    ato.neutrons=(Int(supScr) ?? 0)-ato.protons
                              //  }
                          //      ato.electrons+=ion*(Int(supScr) ?? 1)
                                
                            }
                            //  print(self)
                            
                        }
                    }
                    
                }else if CharacterSet.lowercaseLetters.contains(i) {
                    if !(sym==""){
                        tempSym=sym
                        sym+=String(i)
                        for j in periodicTable{
                            if j.symbol==sym{
                                ato=j
                                for k in periodicTable{
                                    if k.symbol == tempSym{
                                        atoms.remove(at: atoms.count-1)
                                    }
                                }
                                if !(supScr==""){
//                                    if ion==0{
                                        ato.neutrons=(Int(supScr) ?? 0)-ato.protons
//                                    }
//                                    ato.electrons+=ion*(Int(supScr) ?? 1)
                                    
                                }
                                sym=""
                                //print(self)
                                
                            }
                        }
                    }
                }else if superscriptNums.contains(String(i)){
                    //print(self)
                    
                    for j in superscriptNums.indices{
                        if String(i)==superscriptNums[j]{
                            supScr+=String(j)
                            print(supScr)
                        }
                    }
                }else if subscriptNums.contains(String(i)){
                    //print(self)
                    for j in subscriptNums.indices{
                        if String(i)==subscriptNums[j]{
                            subScr+=String(j)
                            print(subScr)
                        }
                    }
                    //                }else if ionSigns.contains(String(i)){
                    //                    if String(i)==ionSigns[0]{
                    //                        ion+=1
                    //                    }else{
                    //                        ion-=1
                    //                    }
                    //                    print(ion) 
                    //                    this was cancelled due to time
                }else{
                    print(self)
                    
                }
                if !(ato.symbol=="Q"){
                    if subScr=="0"{
                        atoms.append(ato)
                    }else{
                        for _ in 1..<(Int(subScr) ?? 0){
                            atoms.append(ato)
                            
                        }
                        subScr="0"
                    }
                    //                    ato=errorAtom
                }
            }
            
            mole.append(Molecule(atoms: atoms))
            
            return mole
        }
        //    print(self)
        return [Molecule(atoms: [])] 
    }
}


var errorAtom = Atom(symbol: "Q", name: "If you see this, there is an error", electrons: 1, neutrons: 1, protons: 1, groupNumber: 1, periodNumber: 1)

struct Molecule: Identifiable{
    var id=UUID()
    var atoms: [Atom]
    //    var atomviews: [AtomView] {
    //        return atoms.map {  }
    //    }
    var isValid: Bool{
        for atom in atoms{
            if atom.category == .nobleGas{
                return false
            }
        }
        return true
    }
    var twoDplacement:[[Atom]]{
        var tempAtoms = atoms//a [Atom] input
        var hydro:[Atom]=[]//hydrogen atoms
        var tempTwoDAtoms:[[Atom]]=[atoms]//output
        var totalValence = 0// used to calculate bonds
        var symbolAtoms = tempAtoms.map(){$0.symbol}
        if isValid{//make sure is not noble gas
            
            while symbolAtoms.contains("H"){
                if let i = symbolAtoms.firstIndex(of: "H"){
                    hydro.append(periodicTable[0])
                    tempAtoms.remove(at: i)
                    symbolAtoms.remove(at: i)
                }
            }
            print(hydro)
            if hydro.count>0{
                for i in tempAtoms{
                    totalValence+=i.valence
                }
                let valenceArray = tempAtoms.map {$0.valence}
                var least = 8
                for i in valenceArray{
                    if i<least{
                        least=i
                    }
                }
                if least >= 4{
                    switch hydro.count{
                    case 0:
                        return tempTwoDAtoms
                    case 1:
                        tempTwoDAtoms=[tempAtoms]
                        tempTwoDAtoms[0].insert(periodicTable[0], at: 0)
                        return tempTwoDAtoms
                    case 2:
                        tempTwoDAtoms=[tempAtoms]
                        tempTwoDAtoms[0].insert(periodicTable[0], at: 0)
                        tempTwoDAtoms[0].append(periodicTable[0])
                        return tempTwoDAtoms
                    case 3:
                        tempTwoDAtoms=[tempAtoms]
                        tempTwoDAtoms[0].insert(periodicTable[0], at: 0)
                        tempTwoDAtoms[0].append(periodicTable[0])
                        tempTwoDAtoms.insert([periodicTable[0]], at: 0)
                        return tempTwoDAtoms
                    case 4:
                        tempTwoDAtoms=[tempAtoms]
                        tempTwoDAtoms[0].insert(periodicTable[0], at: 0)
                        tempTwoDAtoms[0].append(periodicTable[0])
                        tempTwoDAtoms.insert([periodicTable[0]], at: 0)
                        tempTwoDAtoms.append([periodicTable[0]])
                        return tempTwoDAtoms
                    default:
                        return [atoms]
                    }
                }
            }
        }
        return [atoms]
    }
    var bonds:[[Bond]]{
        return [[]]
    }
}
enum BondType{
    case ionic, covalent, polarCovalent, metallic, coordinateCovalent
}
struct Bond{
    var type:BondType
    var num:Int
    var direction: Direction
    
}
enum Direction{
    case vert, horiz, left, right
}

