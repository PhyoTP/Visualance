import SwiftUI

struct DictionaryView: View{
    @State var texter = ""
    var filteredElements: [Atom] {
        if texter.isEmpty {
            return periodicTable
        } else {
            return periodicTable.filter { $0.name.lowercased().contains(texter.lowercased()) }
        }
    }
    var body: some View{
        NavigationStack{
            List(filteredElements){element in
                NavigationLink{
                    ElementDetailView(element: element)
                }label: {
                    Text(element.name)
                }
            }
            .navigationTitle("Dictionary")
            .searchable(text: $texter, placement: .navigationBarDrawer, prompt: "Enter element here")
        }
    }
}
