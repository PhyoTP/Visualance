import SwiftUI

struct InfoView: View{
    var body: some View{
        NavigationStack{
            List{
                Section("What is this?"){
                    Text("Visualance is an app that helps you visualise chemistry using structs and circles. It also has a dictionary of all the elements.")
                }
                Section("Who made this?"){
                    Text("I'm Thet Pai, a Burmese student in Singapore and a graduate of the Swift Accelerator Programme Class of 2023.")
                }
                Section("Where did I get this idea?"){
                    Text("I came up with the idea of this app while ideating for Swift Accelerator Programme app ideas, and I remembered I had trouble visualising and counting the valence electrons of an element, so I came up with this. Unfortunately, my group members had a better idea, so I kept this idea for the Swift Student Challenge.")
                }
                Section("How did I make this?"){
                    Text("I first made an atom struct, then a view that shows how the atom looks like using circles and offsets. Then I made an extension that makes a user input into an atom struct. After extensive work to make sure the electrons were placed correctly, I was finally half done. After that, I spent 2 days researching about atom bonds (I'm only 14 after all) and realised that trying to visualise the bonds as well was insanely complicated, so I eventually settled on just making the atoms be side by side and making molecules like NH3 and CH4 be 2d instead. I was planning on making intermetallic compounds as well but offsetting the last electron to simulate free-moving electrons would be too hard. Eventually, I finished making the extension into one that makes a user input into a molecule.")
                }
                Section("What are some limitations?"){
                    Text("Like I said earlier, it cannot visualise intermetallic compounds accurately. In addition to this, it cannot visualise multiple molecules, compounds with too many components, eg glucose, ions, and some I may not be aware about. There cannot be more than 10 of the same element as well.")
                }
                Text("Enjoy!")
                
            }
            
        }
    }
}
