import SwiftUI

struct MoleculeView: View {
    var molecule:Molecule=Molecule(atoms: [errorAtom])
    var body: some View {
        VStack(spacing:-75){
            ForEach(molecule.twoDplacement, id: \.self){layer in
                HStack{
                    ForEach(layer){atom in
                        AtomView(selectedAtom: atom)    
                    }
                }
            }
        }
        
        .onAppear(){
            print(molecule.twoDplacement)
        }
    }
}

struct MoleculeView_Previews: PreviewProvider {
    static var previews: some View {
        MoleculeView(molecule: Molecule(atoms: [
            periodicTable[0],periodicTable[0]
        ]))
            .preferredColorScheme(.light)
    }
}
