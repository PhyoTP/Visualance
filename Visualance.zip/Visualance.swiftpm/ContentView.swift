import SwiftUI

struct ContentView: View {
    @State var selected = 1
    var body: some View {
        TabView(selection: $selected) {
            VisualizerView()
                .tabItem { 
                    Label("Visualizer", systemImage: "eyeglasses")
                }
                .tag(1)
            DictionaryView()
                .tabItem { 
                    Label("Dictionary", systemImage: "book")
                }
                .tag(2)
        }
    }
}
