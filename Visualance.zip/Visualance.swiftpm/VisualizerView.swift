import SwiftUI

struct VisualizerView: View{
    @State var molecularFormula = ""
    @State var showSheet = false
    var body: some View{
        VStack{
            Button{
                showSheet=true
            }label: {
                Text("?")
                    .frame(width: 20,height: 20)
                    .background(Color.accentColor)
                    .clipShape(Circle())
                    .foregroundStyle(Color.white)
                    .padding()
            }
            Spacer()
            ForEach(molecularFormula.moleculeCalculated){molecule in
                Spacer()
                MoleculeView(molecule: molecule)
                Spacer()
            }
                
            //AtomView(selectedAtom: molecularFormula.moleculeCalculated)
                
                
                
                
            Spacer()
            TextField("Enter molecular formula",text: $molecularFormula)
                .background(Color.accentColor)
            Group{
                HStack{
                    
                    Text("Isotopes")
                        .frame(width: 110)
                        .background(Color.accentColor)
                        .cornerRadius(30)
                    ForEach(superscriptNums,id:\.self){superscriptNum in
                        Button(superscriptNum){
                            molecularFormula+=superscriptNum
                        }
                        .frame(width: 20, height: 20)
                        .background(Color.accentColor)
                        .foregroundColor(.secondary)
                        .cornerRadius(5)
                    }
                }
                HStack{
                    
                    Text("Atom Amount")
                        .frame(width: 110)
                        .background(Color.accentColor)
                    
                        .cornerRadius(30)
                    ForEach(subscriptNums,id:\.self){subscriptNum in
                        Button(subscriptNum){
                            molecularFormula+=subscriptNum
                        }
                        .frame(width: 20, height: 20)
                        .background(Color.accentColor)
                        .foregroundColor(.secondary)
                        .cornerRadius(5)
                    }
                }
            }
            
        }
        .sheet(isPresented: $showSheet, content: {
            InfoView()
        })
    }
    
}
struct VisualizerView_Previews: PreviewProvider {
    static var previews: some View {
        VisualizerView()
            .preferredColorScheme(.light)
    }
}
